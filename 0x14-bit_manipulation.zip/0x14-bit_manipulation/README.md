# alx-low_level_programming
alx low level programming with C
Bit _Operations in C_.
They include:
1. Bitwise AND (&).
2. Bitwise OR (|).
3. Bitwise Exclusive Or (^)
4. Exclusive Nor (~).
5. Left Shift <<.
6. Right Shift >>.
